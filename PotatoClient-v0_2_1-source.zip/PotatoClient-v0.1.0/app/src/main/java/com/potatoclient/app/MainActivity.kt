package com.potatoclient.app

import android.app.Activity
import android.app.AlertDialog
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val cBg = Color.rgb(13, 19, 14)
    private val cPanel = Color.rgb(27, 39, 29)
    private val cGreen = Color.rgb(174, 224, 133)
    private val cText = Color.rgb(235, 241, 232)
    private val cMuted = Color.rgb(166, 183, 163)

    private val mcPkg = "com.mojang.minecraftpe"
    private val reqImport = 41
    private val contentExts = listOf(".mcpack", ".mcaddon", ".mcworld", ".mctemplate")

    private lateinit var content: LinearLayout
    private lateinit var store: Store
    private var selCat: Category? = null
    private var onBack: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        showHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val b = onBack
        if (b != null) b() else super.onBackPressed()
    }

    // ---------- screens ----------

    private fun baseScreen(title: String, subtitle: String, back: (() -> Unit)?) {
        onBack = back
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(cBg)
        scroll.fitsSystemWindows = true // keeps content clear of system bars on Android 15
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(content)
        setContentView(scroll)
        addText("🥔 POTATO CLIENT", 13f, cGreen, true)
        addText(title, 29f, cText, true, top = 10)
        addText(subtitle, 14f, cMuted, false, top = 5, bottom = 20)
    }

    private fun showHome() {
        baseScreen("Client hub", "Toggle modules, manage content and open launcher helpers for Minecraft Bedrock.", null)

        val hero = card()
        hero.addView(label("CURRENT PROFILE", 11f, cMuted, true))
        hero.addView(label("${store.profile} MODE", 24f, cGreen, true, 8))
        hero.addView(label(profileDescription(), 13f, cText, false, 6))
        content.addView(hero)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        PROFILES.keys.forEach { p ->
            val sel = store.profile == p
            val b = Button(this).apply {
                this.text = p
                isAllCaps = false
                textSize = 12f
                setTextColor(if (sel) Color.BLACK else cText)
                setBackgroundTintList(ColorStateList.valueOf(if (sel) cGreen else cPanel))
                setOnClickListener {
                    store.applyProfile(p)
                    showHome()
                    Toast.makeText(this@MainActivity, "$p applied to your module settings.", Toast.LENGTH_SHORT).show()
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        }
        content.addView(row)

        addSectionTitle("QUICK TOGGLES")
        listOf("fps", "cps", "keys", "zoom").mapNotNull { byId(it) }.forEach { m ->
            val c = card()
            c.addView(switchRow(m.name, store.on(m)) { store.setOn(m, it) })
            content.addView(c)
        }

        val mods = CATALOG.filter { it.support == Support.MOD }
        val modsOn = mods.count { store.on(it) }
        addSectionTitle("HUB")
        addMenuCard("Modules", "$modsOn of ${mods.size} mods enabled · HUD, visual, performance, utility") { showModules() }
        addMenuCard("Launcher & imports", "Open Minecraft or LeviLauncher, send .mcpack / .mcworld files to the game") { showLauncher() }
        addMenuCard("In-game checklist", "Your video settings to apply by hand in Minecraft") { showChecklist() }
        addMenuCard("Config backup", "Share, copy or import your settings as JSON") { showConfig() }
        addMenuCard("Device information", "Android version, real RAM and launcher compatibility") { showDeviceInfo() }

        addText("VERSION 0.2.1  •  EARLY PREVIEW", 10f, cMuted, true, top = 24)
        addText(
            "Potato Client is a companion app. It cannot inject modules into Minecraft or guarantee extra FPS. " +
                "Items marked NEEDS IN-GAME MOD are saved settings that only matter if a compatible mod reads them. " +
                "Not affiliated with Flarial, Atlas, LeviLauncher or Mojang.",
            12f, cMuted, false, top = 8
        )
    }

    private fun profileDescription(): String = when (store.profile) {
        "Potato" -> "Lowest visual load. Best starting point for 2GB–3GB RAM devices."
        "Balanced" -> "A middle ground between visual detail and performance."
        else -> "Keeps more visual detail. May be harder on low-end devices."
    }

    private fun showModules() {
        val mods = CATALOG.filter { it.support == Support.MOD }
        baseScreen("Modules", "${mods.count { store.on(it) }} of ${mods.size} mods enabled", { showHome() })

        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tabs: List<Category?> = listOf<Category?>(null) + Category.values().toList()
        tabs.forEach { cat ->
            val sel = selCat == cat
            val b = Button(this).apply {
                this.text = cat?.label ?: "All"
                isAllCaps = false
                textSize = 12f
                setTextColor(if (sel) Color.BLACK else cText)
                setBackgroundTintList(ColorStateList.valueOf(if (sel) cGreen else cPanel))
                setOnClickListener { selCat = cat; showModules() }
            }
            chips.addView(b, LinearLayout.LayoutParams(-2, dp(42)).apply { marginEnd = dp(6) })
        }
        scroll.addView(chips)
        content.addView(scroll)
        content.addView(View(this), LinearLayout.LayoutParams(-1, dp(14)))

        val shown = CATALOG.filter { selCat == null || it.cat == selCat }
        shown.forEach { content.addView(moduleCard(it)) }
        addAction("Turn everything in this view off", filled = false) {
            shown.forEach { store.setOn(it, false) }
            showModules()
        }
        addAction("Back to dashboard", filled = true) { showHome() }
    }

    private fun moduleCard(m: Mod): LinearLayout {
        val c = card()
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        names.addView(label(m.name, 16f, cText, true))
        names.addView(label(m.support.badge, 10f, cGreen, true, 2))
        top.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(makeSwitch(store.on(m)) { store.setOn(m, it) })
        c.addView(top)
        c.addView(label(m.desc, 12f, cMuted, false, 6))
        c.addView(label("Tap for details and options ›", 11f, cGreen, false, 6))
        c.setOnClickListener { showModule(m) }
        return c
    }

    private fun showModule(m: Mod) {
        baseScreen(m.name, "${m.cat.label} · ${m.support.badge.lowercase()}", { showModules() })
        content.addView(card().apply {
            addView(switchRow(if (m.support == Support.MANUAL) "Include in checklist" else "Enabled", store.on(m)) { store.setOn(m, it) })
        })
        content.addView(card().apply {
            addView(label("ABOUT", 11f, cMuted, true))
            addView(label(m.desc, 13f, cText, false, 6))
            addView(label(m.support.note, 12f, cMuted, false, 8))
        })
        if (m.opts.isNotEmpty()) addSectionTitle("OPTIONS")
        m.opts.forEach { op ->
            val c = card()
            when (op) {
                is Opt.Toggle -> c.addView(switchRow(op.label, store.bool(m, op)) { store.setBool(m, op, it) })
                is Opt.Slider -> c.addView(sliderRow(op.label, op.min, op.max, store.int(m, op), op.unit) { store.setInt(m, op, it) })
                is Opt.Choice -> {
                    c.addView(label(op.label, 13f, cMuted, false, bottom = 8))
                    c.addView(choiceRow(op.choices, store.str(m, op)) { store.setStr(m, op, it) })
                }
            }
            content.addView(c)
        }
        addAction("Reset this module", filled = false) { store.reset(m); showModule(m) }
        addAction("Back to modules", filled = true) { showModules() }
    }

    private fun showLauncher() {
        baseScreen("Launcher & imports", "Helpers around the official game. Potato Client does not run or patch Minecraft.", { showHome() })

        val mc = packageManager.getLaunchIntentForPackage(mcPkg)
        infoCard("Minecraft Bedrock", if (mc != null) "Installed" else "Not found. Install it from Google Play.")
        if (mc != null) addAction("Open Minecraft") { startActivity(mc) }

        val levi = findLevi()
        infoCard("LeviLauncher", if (levi != null) "Installed: ${levi.first}" else "Not found")
        if (levi != null) addAction("Open ${levi.first}") { startActivity(levi.second) }
        else addAction("View LeviLauncher on GitHub", filled = false) {
            openUrl("https://github.com/LiteLDev/LeviLaunchroid")
        }
        addText(
            "LeviLauncher is a separate, open-source Android launcher. It runs your own official Minecraft APK, can keep several versions, " +
                "and supports native mods. It needs a legitimate copy of the game, Android 9 or newer and an ARM64 device.",
            12f, cMuted, false, top = 10
        )

        addSectionTitle("IMPORT CONTENT")
        addText(
            "Pick a ${contentExts.joinToString(" / ")} file and Potato Client hands it to Minecraft to import. " +
                "If Minecraft doesn't pick it up, open the file from your Files app and choose Minecraft.",
            12f, cMuted, false, bottom = 4
        )
        addAction("Choose a content file") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),
                reqImport
            )
        }

        addSectionTitle("ABOUT OTHER CLIENTS")
        infoCard("Flarial", "Bedrock client with a ClickGUI and many modules. Windows 10/11, with an Android build in beta.")
        infoCard("Atlas Client", "Mobile client with HUD and visual tools such as keystrokes, CPS and fullbright.")
        addBackButton { showHome() }
    }

    private fun findLevi(): Pair<String, Intent>? {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = packageManager.queryIntentActivities(q, 0)
            .firstOrNull { it.loadLabel(packageManager).toString().contains("levi", ignoreCase = true) }
            ?: return null
        val intent = packageManager.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return null
        return hit.loadLabel(packageManager).toString() to intent
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (e: Exception) { toast("No browser found.") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqImport || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val name = displayName(uri)
        if (contentExts.none { name.endsWith(it, ignoreCase = true) }) {
            toast("That isn't a Minecraft content file (${contentExts.joinToString(", ")}).")
            return
        }
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/octet-stream")
            .setPackage(mcPkg)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivity(i) }
        catch (e: Exception) { toast("Minecraft didn't accept the file directly. Open it from your Files app instead.") }
    }

    private fun displayName(uri: Uri): String {
        val fromProvider = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
        return fromProvider ?: uri.lastPathSegment ?: ""
    }

    private fun showChecklist() {
        baseScreen("In-game checklist", "Set these by hand in Minecraft → Settings → Video. Based on your ${store.profile} profile and edits.", { showHome() })
        val items = CATALOG.filter { it.support == Support.MANUAL && store.on(it) }
        if (items.isEmpty()) addText("Nothing is included yet. Turn items on under Modules → Performance.", 13f, cText, false)
        items.forEach { m -> infoCard(m.name, m.opts.joinToString(" · ") { store.optionText(m, it) }) }
        addText("Setting names and availability vary by Minecraft version and device.", 12f, cMuted, false, top = 8)
        addAction("Edit these values", filled = false) { selCat = Category.PERFORMANCE; showModules() }
        addBackButton { showHome() }
    }

    private fun showConfig() {
        baseScreen("Config backup", "Export your module settings as JSON, or import a saved config.", { showHome() })
        addAction("Share config") {
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, store.export()),
                    "Share config"
                )
            )
        }
        addAction("Copy config", filled = false) {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Potato Client config", store.export()))
            toast("Config copied.")
        }
        addSectionTitle("IMPORT")
        val input = EditText(this).apply {
            hint = "Paste a Potato Client config here"
            setHintTextColor(cMuted)
            setTextColor(cText)
            setBackgroundColor(cPanel)
            textSize = 12f
            minLines = 6
            gravity = Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        content.addView(input, LinearLayout.LayoutParams(-1, -2))
        addAction("Apply imported config") {
            try {
                val n = store.import(input.text.toString())
                toast("Imported settings for $n modules.")
            } catch (e: Exception) {
                toast("That isn't a valid Potato Client config.")
            }
        }
        addAction("Reset all modules to defaults", filled = false) {
            AlertDialog.Builder(this)
                .setMessage("Reset every module and your profile to defaults?")
                .setPositiveButton("Reset") { _, _ -> store.resetAll(); showConfig() }
                .setNegativeButton("Cancel", null)
                .show()
        }
        addBackButton { showHome() }
    }

    private fun showDeviceInfo() {
        baseScreen("Device information", "Basic information reported by Android.", { showHome() })
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val mb = 1024L * 1024L
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown"
        infoCard("Android version", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        infoCard("Device model", "${Build.MANUFACTURER} ${Build.MODEL}")
        infoCard("CPU architecture", abi)
        infoCard("Total RAM", "${mi.totalMem / mb} MB")
        infoCard("Available RAM right now", "${mi.availMem / mb} MB" + if (mi.lowMemory) " (system is low on memory)" else "")
        val leviOk = Build.VERSION.SDK_INT >= 28 && Build.SUPPORTED_ABIS.contains("arm64-v8a")
        infoCard("LeviLauncher requirements", if (leviOk) "Android 9+ and ARM64: met" else "Android 9+ and ARM64: not met")
        addText("RAM figures are for the whole device, not just Minecraft.", 12f, cMuted, false, top = 12)
        addBackButton { showHome() }
    }

    // ---------- widgets ----------

    private fun makeSwitch(checked: Boolean, onChange: (Boolean) -> Unit): Switch = Switch(this).apply {
        isChecked = checked
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        setThumbTintList(ColorStateList(states, intArrayOf(cGreen, cMuted)))
        setTrackTintList(ColorStateList(states, intArrayOf(Color.rgb(62, 96, 56), Color.rgb(48, 58, 48))))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    private fun switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(label(title, 15f, cText, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(makeSwitch(checked, onChange))
        return row
    }

    private fun sliderRow(title: String, lo: Int, hi: Int, value: Int, unit: String, onChange: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lbl = label("$title: $value$unit", 13f, cText, false, bottom = 6)
        val sb = SeekBar(this).apply {
            this.max = hi - lo
            progress = value - lo
            progressTintList = ColorStateList.valueOf(cGreen)
            thumbTintList = ColorStateList.valueOf(cGreen)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                lbl.text = "$title: $v$unit"
                if (fromUser) onChange(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(lbl)
        box.addView(sb)
        return box
    }

    private fun choiceRow(choices: List<String>, selected: String, onPick: (String) -> Unit): View {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val buttons = mutableListOf<Pair<String, Button>>()
        var current = selected
        fun restyle() {
            buttons.forEach { (name, b) ->
                val on = name == current
                b.setTextColor(if (on) Color.BLACK else cText)
                b.setBackgroundTintList(ColorStateList.valueOf(if (on) cGreen else cBg))
            }
        }
        choices.forEach { c ->
            val b = Button(this).apply {
                this.text = c
                isAllCaps = false
                textSize = 12f
                setOnClickListener { current = c; restyle(); onPick(c) }
            }
            buttons.add(c to b)
            row.addView(b, LinearLayout.LayoutParams(-2, dp(44)).apply { marginEnd = dp(6) })
        }
        restyle()
        scroll.addView(row)
        return scroll
    }

    private fun addAction(title: String, filled: Boolean = true, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = title
            isAllCaps = false
            setTextColor(if (filled) Color.BLACK else cText)
            setBackgroundTintList(ColorStateList.valueOf(if (filled) cGreen else cPanel))
            setOnClickListener { action() }
        }
        content.addView(b, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
    }

    private fun addBackButton(back: () -> Unit) = addAction("Back to dashboard", filled = true, action = back)

    private fun addMenuCard(title: String, desc: String, action: () -> Unit) {
        val c = card()
        c.addView(label(title, 17f, cText, true))
        c.addView(label(desc, 12f, cMuted, false, 5))
        c.setOnClickListener { action() }
        c.isClickable = true
        content.addView(c)
    }

    private fun infoCard(title: String, value: String) {
        val c = card()
        c.addView(label(title, 12f, cMuted, false))
        c.addView(label(value, 16f, cText, true, 5))
        content.addView(c)
    }

    private fun addSectionTitle(value: String) = addText(value, 12f, cGreen, true, top = 24, bottom = 10)

    private fun addText(value: String, size: Float, color: Int, bold: Boolean, top: Int = 0, bottom: Int = 0) {
        content.addView(label(value, size, color, bold, top, bottom))
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean, top: Int = 0, bottom: Int = 0): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(top), 0, dp(bottom))
            gravity = Gravity.START
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        setBackgroundColor(cPanel)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
