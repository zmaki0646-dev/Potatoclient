package com.potatoclient.app

enum class Category(val label: String) {
    HUD("HUD"), VISUAL("Visual"), PERFORMANCE("Performance"), UTILITY("Utility")
}

enum class Support(val badge: String, val note: String) {
    MANUAL(
        "MANUAL SETTING",
        "Potato Client can't change this inside Minecraft. Set it yourself in Minecraft's settings; your choice appears in the In-game checklist."
    ),
    MOD(
        "NEEDS IN-GAME MOD",
        "Saved to your config. It only does something in-game if a compatible native mod reads it, for example one loaded through LeviLauncher. Potato Client cannot inject modules into Minecraft on its own."
    )
}

sealed class Opt(val key: String, val label: String) {
    class Toggle(key: String, label: String, val def: Boolean) : Opt(key, label)
    class Slider(key: String, label: String, val min: Int, val max: Int, val def: Int, val unit: String = "") : Opt(key, label)
    class Choice(key: String, label: String, val choices: List<String>, val def: String) : Opt(key, label)
}

class Mod(
    val id: String,
    val name: String,
    val cat: Category,
    val support: Support,
    val desc: String,
    val opts: List<Opt> = emptyList(),
    val defOn: Boolean = false
)

private fun hudOpts(vararg extra: Opt): List<Opt> = extra.toList() + listOf(
    Opt.Choice("pos", "Position", listOf("Top left", "Top right", "Bottom left", "Bottom right"), "Top left"),
    Opt.Slider("scale", "Size", 50, 200, 100, "%"),
    Opt.Slider("opacity", "Opacity", 20, 100, 90, "%"),
    Opt.Toggle("bg", "Background panel", true)
)

private fun hud(id: String, name: String, desc: String, vararg extra: Opt) =
    Mod(id, name, Category.HUD, Support.MOD, desc, hudOpts(*extra))

private fun vis(id: String, name: String, desc: String, vararg opts: Opt) =
    Mod(id, name, Category.VISUAL, Support.MOD, desc, opts.toList())

private fun perf(id: String, name: String, desc: String, opt: Opt) =
    Mod(id, name, Category.PERFORMANCE, Support.MANUAL, desc, listOf(opt), defOn = true)

private fun util(id: String, name: String, desc: String, vararg opts: Opt) =
    Mod(id, name, Category.UTILITY, Support.MOD, desc, opts.toList())

val CATALOG: List<Mod> = listOf(
    // ---- HUD ----
    hud("fps", "FPS counter", "Shows your current frame rate on screen."),
    hud("cps", "CPS display", "Shows how many taps or clicks per second you make."),
    hud("keys", "Keystrokes", "Shows a live overlay of the controls you are pressing.",
        Opt.Toggle("jump", "Show jump key", true),
        Opt.Toggle("clicks", "Show click counters", true)),
    hud("armor", "Armor HUD", "Shows your equipped armor on screen.",
        Opt.Toggle("dur", "Show durability", true),
        Opt.Choice("layout", "Layout", listOf("Vertical", "Horizontal"), "Vertical")),
    hud("speed", "Speed display", "Shows how fast you are moving.",
        Opt.Choice("unit", "Unit", listOf("Blocks/s", "km/h"), "Blocks/s")),
    hud("coords", "Coordinates", "Shows your position in the world.",
        Opt.Toggle("dir", "Show facing direction", true)),
    hud("reach", "Reach display", "Shows the distance of your last hit (display only).",
        Opt.Slider("dec", "Decimal places", 0, 3, 1)),
    hud("clock", "Clock", "Shows the time on screen.",
        Opt.Choice("fmt", "Format", listOf("12-hour", "24-hour"), "24-hour"),
        Opt.Toggle("world", "Show in-game time instead", false)),

    // ---- Visual ----
    vis("fullbright", "Fullbright", "Makes dark areas brighter. Some servers don't allow brightness mods.",
        Opt.Slider("level", "Brightness boost", 1, 10, 5)),
    vis("motionblur", "Motion blur", "Adds a blur while you turn the camera. Costs extra GPU time on weak phones.",
        Opt.Slider("amt", "Strength", 1, 10, 4)),
    vis("zoom", "Zoom", "Zooms your view while a key or button is held.",
        Opt.Slider("factor", "Zoom factor", 2, 10, 4, "x"),
        Opt.Toggle("smooth", "Smooth zoom animation", true),
        Opt.Toggle("adjust", "Adjust level while zoomed", true)),
    vis("chunkborders", "Chunk borders", "Draws chunk edges, useful for building and farm design.",
        Opt.Choice("style", "Style", listOf("Lines", "Corners only"), "Lines"),
        Opt.Slider("range", "Range", 1, 8, 3, " chunks")),
    vis("lowfire", "Low fire", "Lowers the fire overlay so it blocks less of your view.",
        Opt.Slider("height", "Fire height", 20, 100, 50, "%")),
    vis("crosshair", "Custom crosshair", "Replaces the crosshair shape and size.",
        Opt.Choice("shape", "Shape", listOf("Cross", "Dot", "Circle"), "Cross"),
        Opt.Slider("size", "Size", 50, 200, 100, "%")),

    // ---- Performance (set manually in Minecraft's Video settings) ----
    perf("renderdist", "Render distance", "Fewer chunks means a big FPS and heat win on weak phones.",
        Opt.Slider("chunks", "Target", 2, 32, 4, " chunks")),
    perf("simdist", "Simulation distance", "How far away the world keeps updating. Set it if your version offers it.",
        Opt.Slider("chunks", "Target", 4, 12, 4, " chunks")),
    perf("fancygfx", "Fancy graphics", "Off is lighter on the GPU.",
        Opt.Choice("mode", "Target", listOf("Off", "On"), "Off")),
    perf("fancyleaves", "Fancy leaves", "Off draws simpler foliage. Only shown in some versions.",
        Opt.Choice("mode", "Target", listOf("Off", "On"), "Off")),
    perf("particles", "Particles", "Fewer particles help in busy scenes.",
        Opt.Choice("mode", "Target", listOf("Minimal", "Decreased", "Full"), "Minimal")),
    perf("skies", "Beautiful skies", "Off skips extra sky rendering. Only shown in some versions.",
        Opt.Choice("mode", "Target", listOf("Off", "On"), "Off")),
    perf("packs", "Resource pack weight", "Heavy packs raise memory use and loading time.",
        Opt.Choice("weight", "Target", listOf("None", "Light only", "Any"), "Light only")),

    // ---- Utility ----
    util("togglesprint", "Toggle sprint", "Keeps you sprinting without holding the control.",
        Opt.Toggle("hud", "Show status on screen", true)),
    util("freelook", "Freelook", "Look around without turning your character.",
        Opt.Toggle("hold", "Hold to activate", true))
)

fun byId(id: String): Mod? = CATALOG.firstOrNull { it.id == id }

/** Profile presets: "moduleId.optionKey" (or "moduleId.on") -> value. */
val PROFILES: Map<String, Map<String, String>> = linkedMapOf(
    "Potato" to mapOf(
        "renderdist.chunks" to "4", "simdist.chunks" to "4", "fancygfx.mode" to "Off",
        "fancyleaves.mode" to "Off", "particles.mode" to "Minimal", "skies.mode" to "Off",
        "packs.weight" to "Light only", "motionblur.on" to "false", "chunkborders.on" to "false"
    ),
    "Balanced" to mapOf(
        "renderdist.chunks" to "8", "simdist.chunks" to "6", "fancygfx.mode" to "Off",
        "fancyleaves.mode" to "Off", "particles.mode" to "Decreased", "skies.mode" to "Off",
        "packs.weight" to "Light only", "motionblur.on" to "false"
    ),
    "Visual" to mapOf(
        "renderdist.chunks" to "12", "simdist.chunks" to "8", "fancygfx.mode" to "On",
        "fancyleaves.mode" to "On", "particles.mode" to "Full", "skies.mode" to "On",
        "packs.weight" to "Any"
    )
)
