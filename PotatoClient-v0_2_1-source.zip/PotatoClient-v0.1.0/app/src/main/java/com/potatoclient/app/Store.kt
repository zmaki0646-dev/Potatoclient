package com.potatoclient.app

import android.content.Context
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("potato", Context.MODE_PRIVATE)

    var profile: String
        get() = sp.getString("profile", "Potato") ?: "Potato"
        set(v) { sp.edit().putString("profile", v).apply() }

    fun on(m: Mod): Boolean = sp.getBoolean("on.${m.id}", m.defOn)
    fun setOn(m: Mod, v: Boolean) { sp.edit().putBoolean("on.${m.id}", v).apply() }

    fun bool(m: Mod, o: Opt.Toggle): Boolean = sp.getBoolean("${m.id}.${o.key}", o.def)
    fun setBool(m: Mod, o: Opt.Toggle, v: Boolean) { sp.edit().putBoolean("${m.id}.${o.key}", v).apply() }

    fun int(m: Mod, o: Opt.Slider): Int = sp.getInt("${m.id}.${o.key}", o.def)
    fun setInt(m: Mod, o: Opt.Slider, v: Int) { sp.edit().putInt("${m.id}.${o.key}", v).apply() }

    fun str(m: Mod, o: Opt.Choice): String = sp.getString("${m.id}.${o.key}", o.def) ?: o.def
    fun setStr(m: Mod, o: Opt.Choice, v: String) { sp.edit().putString("${m.id}.${o.key}", v).apply() }

    fun reset(m: Mod) {
        val e = sp.edit()
        e.remove("on.${m.id}")
        m.opts.forEach { e.remove("${m.id}.${it.key}") }
        e.apply()
    }

    fun resetAll() { sp.edit().clear().apply() }

    fun applyProfile(name: String) {
        profile = name
        CATALOG.filter { it.support == Support.MANUAL }.forEach { setOn(it, true) }
        PROFILES[name]?.forEach { (k, v) ->
            val parts = k.split(".", limit = 2)
            val m = byId(parts[0]) ?: return@forEach
            if (parts[1] == "on") { setOn(m, v == "true"); return@forEach }
            when (val op = m.opts.firstOrNull { it.key == parts[1] }) {
                is Opt.Slider -> setInt(m, op, v.toInt())
                is Opt.Choice -> setStr(m, op, v)
                is Opt.Toggle -> setBool(m, op, v == "true")
                null -> {}
            }
        }
    }

    fun optionText(m: Mod, o: Opt): String = when (o) {
        is Opt.Toggle -> if (bool(m, o)) "On" else "Off"
        is Opt.Slider -> "${int(m, o)}${o.unit}"
        is Opt.Choice -> str(m, o)
    }

    fun export(): String {
        val root = JSONObject()
        root.put("app", "PotatoClient")
        root.put("version", "0.2.1")
        root.put("profile", profile)
        val mods = JSONObject()
        for (m in CATALOG) {
            val o = JSONObject()
            o.put("enabled", on(m))
            val opts = JSONObject()
            for (op in m.opts) when (op) {
                is Opt.Toggle -> opts.put(op.key, bool(m, op))
                is Opt.Slider -> opts.put(op.key, int(m, op))
                is Opt.Choice -> opts.put(op.key, str(m, op))
            }
            o.put("options", opts)
            mods.put(m.id, o)
        }
        root.put("modules", mods)
        return root.toString(2)
    }

    /** Returns how many modules were found in the config. Throws on invalid JSON. */
    fun import(text: String): Int {
        val root = JSONObject(text)
        val mods = root.getJSONObject("modules")
        var n = 0
        for (m in CATALOG) {
            val o = mods.optJSONObject(m.id) ?: continue
            if (o.has("enabled")) setOn(m, o.optBoolean("enabled"))
            val opts = o.optJSONObject("options")
            if (opts != null) {
                for (op in m.opts) {
                    if (!opts.has(op.key)) continue
                    when (op) {
                        is Opt.Toggle -> setBool(m, op, opts.optBoolean(op.key, op.def))
                        is Opt.Slider -> setInt(m, op, opts.optInt(op.key, op.def).coerceIn(op.min, op.max))
                        is Opt.Choice -> {
                            val v = opts.optString(op.key, op.def)
                            if (v in op.choices) setStr(m, op, v)
                        }
                    }
                }
            }
            n++
        }
        root.optString("profile").takeIf { it in PROFILES }?.let { profile = it }
        return n
    }
}
