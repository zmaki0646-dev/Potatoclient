# Potato Client v0.1.1

A beginner-friendly Android companion app prototype for Minecraft Bedrock players using lower-end phones.

## Current features
- Dark green dashboard
- Potato, Balanced, and Visual profile selector (recommendation presets only)
- Basic device and app-memory information
- Recommended Minecraft video settings
- Resource pack manager placeholder

## Features (v0.2.1)
- Module hub with 23 toggleable modules across HUD, Visual, Performance and Utility, each with its own options (sliders, switches, choices)
- Potato / Balanced / Visual profiles that set many modules at once
- Quick toggles on the dashboard
- In-game checklist of video settings to apply by hand
- Launcher helpers: open Minecraft, detect and open LeviLauncher, send .mcpack / .mcaddon / .mcworld / .mctemplate files to Minecraft
- Config export/import as JSON (share, copy, paste)
- Device info with real RAM and LeviLauncher compatibility check

## Important limitations
Potato Client is a companion app. It does not modify Minecraft, inject modules, or guarantee FPS gains. Each module is labelled:
- **MANUAL SETTING**: you set it in Minecraft; the app remembers the value and lists it in the checklist.
- **NEEDS IN-GAME MOD**: only a saved setting. It has an effect only if a compatible native mod (for example one loaded via LeviLauncher) reads it.

Not affiliated with Flarial, Atlas, LeviLauncher or Mojang.

## Project
- App ID: `com.potatoclient.app`, Kotlin, Android framework views only
- Minimum Android: API 23, compile SDK 35, version 0.2.1

## Building without a local Android SDK
Push this folder to a GitHub repository. The workflow in `.github/workflows/build.yml` builds the debug APK on every push (or run it manually from the Actions tab). Download `PotatoClient-debug-apk` from the run's Artifacts, unzip it, and install the APK. Android will ask you to allow installing from your browser or file manager.
